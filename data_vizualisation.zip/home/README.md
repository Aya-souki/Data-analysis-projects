# FordGoBike-trip Dataset:
## by Souki Aya


## Dataset

The chosen dataset,ford_go_bike_2019.csv, has 183412 and 16 columns. It contains informations about the trajectories of individual trip by bycicle in the bay of San Fransisco in february 2019. It features information about the user, the bike, the trajectory, and the time of the trip. As I noticed most trips happen on the same station, I decided to pay attention to the top 10 start stations with the most trips, hence the following analysis.

## Summary of Findings

- Univariate exploration:  During the day, there are more trips in the morning and afternoon than the night. AThere are more subscribers than customers, which makes sense given the pricing. For the gender groups, the number of trips in male riders is more than twice higher than the number of trips in females. It needs to be investigated more. Most of riders are 25 to 35 years old and the duration of trips is around 30 minutes.

-Bivariate exploration: there is a slightly positive correlation between age and duration of trips. While trips from Caltrain station 2 pick up in the morning, this is obviously not the case for every station as the morning and afternoon trip counts are more or less close in number.  No obvious correlation is deduced between stations and gender percentage. Subscribers' numbers is higher than customers' in every station. We notice that there are noticibly more customers in Berry St at 4th st and Market st at 10th st.

-Multivariate exploration: I think that dividing users into customers and subscribers denoted the difference between the two. While the number of trips of tend to pick up near tourist attractions (like Ferry Building per example, which has the highest number of trips), subscribers's trips are higher in station with public transportation (Caltrain station per example).

## Key Insights for Presentation

1-Most trips occur in the morning, with afternoon not far behind. Relatively fewer trips occur at night.
2- All of the start stations with the most trips in San Francisco are connected to public transportations such as Caltrain, Bart and Ferry.
3-While the number of trips of tend to pick up near tourist attractions (like Ferry Building per example, which has the highest number of trips), subscribers's trips are higher in station with public transportation (Caltrain station per example).
